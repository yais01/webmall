<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubOrderItem extends Model
{
    //
}
