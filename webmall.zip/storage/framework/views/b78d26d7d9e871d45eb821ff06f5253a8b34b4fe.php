


<?php $__env->startSection('content'); ?>


<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('mall-cart', [])->dom;
} elseif ($_instance->childHasBeenRendered('ek1VU0D')) {
    $componentId = $_instance->getRenderedChildComponentId('ek1VU0D');
    $componentTag = $_instance->getRenderedChildComponentTagName('ek1VU0D');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ek1VU0D');
} else {
    $response = \Livewire\Livewire::mount('mall-cart', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ek1VU0D', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmall\resources\views/cart/index.blade.php ENDPATH**/ ?>