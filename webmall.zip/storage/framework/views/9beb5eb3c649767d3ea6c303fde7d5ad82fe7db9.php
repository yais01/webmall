<div class="custom-col-style-2 custom-col-4">
    <div class="product-wrapper product-border mb-24">
        <div class="product-img-3">
            <a href="<?php echo e(route('products.show', $product)); ?>">
                <?php if(!empty($product->cover_img)): ?>
                    <img src="<?php echo e(asset('storage/'.$product->cover_img)); ?>" alt="">
                <?php else: ?>
                    <img src="/assets/img/product/electro/1.jpg" alt="">
                <?php endif; ?>
            </a>
            <div class="product-action-right">
                <a class="animate-right" href="<?php echo e(route('products.show', $product)); ?>" title="View">
                    <i class="pe-7s-look"></i>
                </a>
                <a class="animate-top" title="Add To Cart" href="<?php echo e(route('cart.add', $product->id)); ?>">
                    <i class="pe-7s-cart"></i>
                </a>
                <a class="animate-left" title="Wishlist" href="#">
                    <i class="pe-7s-like"></i>
                </a>
            </div>
        </div>
        <div class="product-content-4 text-center">
            <div class="product-rating-4">
                <i class="icofont icofont-star yellow"></i>
                <i class="icofont icofont-star yellow"></i>
                <i class="icofont icofont-star yellow"></i>
                <i class="icofont icofont-star yellow"></i>
                <i class="icofont icofont-star"></i>
            </div>
            <h4><a href="<?php echo e(route('products.show', $product)); ?>"><?php echo e($product->name); ?></a></h4>
            <span><?php echo e($product->description); ?></span>
            <h5>IDR <?php echo e($product->price); ?></h5>
        <p><?php echo e($product->shop->owner->name ?? 'n/a'); ?></p>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\webmall\resources\views/product/_single_product.blade.php ENDPATH**/ ?>