


<?php $__env->startSection('content'); ?>

    <h4>Orders</h4>

    <table class="table">
        <thead>
            <tr>
                <th>Order number</th>
                <th>Status</th>
                <th>Item count</th>
                <th>Shipping Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td scope="row">
                        <?php echo e($subOrder->order->order_number); ?>

                    </td>
                    <td>
                        <?php echo e($subOrder->status); ?>


                        <?php if($subOrder->status != 'completed'): ?>

                            <a href=" <?php echo e(route('seller.order.delivered', $subOrder)); ?> " class="btn btn-primary btn-sm">mark as delivered</button>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php echo e($subOrder->item_count); ?>

                    </td>

                    <td>
                       <?php echo $subOrder->order->shipping_address; ?>

                    </td>

                    <td>
                        <a name="" id="" class="btn btn-primary btn-sm" href="<?php echo e(route('seller.orders.show', $subOrder)); ?>" role="button">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>


        </tbody>
    </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmall\resources\views/sellers/orders/index.blade.php ENDPATH**/ ?>