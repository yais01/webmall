


<?php $__env->startSection('content'); ?>
<h3>Order Summary</h3>

<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Qty</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td scope="row">
                <?php echo e($item->name); ?>

            </td>
            <td>
                <?php echo e($item->pivot->quantity); ?>

            </td>
            <td>
                <?php echo e($item->pivot->price); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmall\resources\views/sellers/orders/show.blade.php ENDPATH**/ ?>