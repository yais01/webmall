

<?php $__env->startSection('content'); ?>

<div class="pl-200 pr-200 overflow clearfix">
    <div class="categori-menu-slider-wrapper clearfix">
        <div class="categories-menu">
            <div class="category-heading">
                <h3> All Departments <i class="pe-7s-angle-down"></i></h3>
            </div>
            <div class="category-menu-list">
                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                        <a href="<?php echo e(route('products.index', ['category_id' => $category->id])); ?>"><?php echo e($category->name); ?><i
                                    class="pe-7s-angle-right"></i></a>

                                    <?php
                                        $children = TCG\Voyager\Models\Category::where('parent_id', $category->id)->get();
                                    ?>

                               <?php if($children->isNotEmpty()): ?>
                                <div class="category-menu-dropdown">

                                    <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="category-dropdown-style category-common3">
                                            <h4 class="categories-subtitle">
                                                <a href="<?php echo e(route('products.index', ['category_id' => $child->id])); ?>">
                                                <?php echo e($child->name); ?>

                                                </a>

                                              </h4>
                                            <?php
                                                $grandChild = TCG\Voyager\Models\Category::where('parent_id', $child->id)->get();
                                            ?>
                                            <?php if($grandChild->isNotEmpty()): ?>
                                                <ul>
                                                    <?php $__currentLoopData = $grandChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="<?php echo e(route('products.index', ['category_id' => $c->id])); ?>"><?php echo e($c->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>

                              <?php endif; ?>
                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        </div>
        <div class="menu-slider-wrapper">
            <div class="menu-style-3 menu-hover text-center">
                <nav>
                    <ul>
                        <li><a href="<?php echo e(url('/')); ?>">home </a>

                        </li>


                        <li><a href="#">blog  <span
                                    class="sticker-new">hot</span></a>

                        </li>
                        <li><a href="#">contact</a></li>
                    </ul>
                </nav>
            </div>
            <div class="slider-area">
                <div class="slider-active owl-carousel">
                    <div class="single-slider single-slider-hm3 bg-img pt-170 pb-173"
                        style="background-image: url(assets/img/slider/jj.jpg)">
                        <div class="slider-animation slider-content-style-3 fadeinup-animated">
                            <h2 style="color: white" class="animated">Marketplace <br>Pasar baru</h2>
                            <h4 style="color: white" class="animated">Kini Hadir </h4>
                            <a class="electro-slider-btn btn-hover" href="<?php echo e(url('/')); ?>">buy now</a>
                        </div>
                    </div>
                    <div class="single-slider single-slider-hm3 bg-img pt-170 pb-173"
                        style="background-image: url(assets/img/slider/aa.jpg)">
                        <div class="slider-animation slider-content-style-3 fadeinup-animated">
                        <h2 style="color: white" class="animated">Marketplace <br>Pasar baru</h2>
                        <h4 style="color: white" class="animated">Kini Hadir </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="electro-product-wrapper wrapper-padding pt-95 pb-45">

        <div class="container-fluid">
            <div class="section-title-4 text-center mb-40">
                <h2>Top Products</h2>
            </div>
            <div class="top-product-style">

                <div>
                    <div id="electro1">
                        <div class="custom-row-2">

                            <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('product._single_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webmall\resources\views/home.blade.php ENDPATH**/ ?>