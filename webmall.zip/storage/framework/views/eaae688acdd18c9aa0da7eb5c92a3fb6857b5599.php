<div>
    

    <div class="cart-main-area pt-95 pb-100">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h1 class="cart-heading">Cart</h1>
                    <div class="table-content table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>remove</th>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>


                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="product-remove">
                                        <a href="<?php echo e(route('cart.destroy', $item['id'])); ?>"><i
                                                class="pe-7s-close"></i></a>

                                    </td>
                                    <td class="product-name"><a href="#"><?php echo e($item['name']); ?> </a></td>
                                    <td class="product-price-cart"><span
                                            class="amount">IDR<?php echo e(Cart::session(auth()->id())->get($item['id'])->getPriceSum()); ?></span>
                                    </td>
                                    <td class="product-quantity">
                                        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('cart-update-form', ['item' => $item])->dom;
} elseif ($_instance->childHasBeenRendered($item['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($item['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($item['id']);
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item['id']);
} else {
    $response = \Livewire\Livewire::mount('cart-update-form', ['item' => $item]);
    $dom = $response->dom;
    $_instance->logRenderedChild($item['id'], $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-5 ml-auto">
                            <div class="cart-page-total">
                                <h2>Cart totals</h2>
                                <ul>
                                    <li>SubTotal<span><?php echo e(\Cart::session(auth()->id())->getSubTotal()); ?></span></li>
                                    <li>Total<span><?php echo e(\Cart::session(auth()->id())->getTotal()); ?></span></li>
                                </ul>
                                <a href="<?php echo e(route('cart.checkout')); ?>">Proceed to checkout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



</div>
<?php /**PATH C:\xampp\htdocs\webmall\resources\views/livewire/mall-cart.blade.php ENDPATH**/ ?>