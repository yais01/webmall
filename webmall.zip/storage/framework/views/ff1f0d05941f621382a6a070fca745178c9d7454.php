<div>

        <input wire:model="quantity"  type="number" wire:change="updateCart">

</div>
<?php /**PATH C:\xampp\htdocs\webmall\resources\views/livewire/cart-update-form.blade.php ENDPATH**/ ?>