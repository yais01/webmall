@extends('layouts.front')


@section('content')


<livewire:mall-cart />


@endsection
