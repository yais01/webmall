<div>

        <input wire:model="quantity"  type="number" wire:change="updateCart">

</div>
